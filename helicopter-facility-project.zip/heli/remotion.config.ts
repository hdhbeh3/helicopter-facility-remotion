import {Config} from '@remotion/cli/config';

// Stable, memory-friendly settings for GitHub Actions (software GL, no GPU).
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setCodec('h264');
Config.setPixelFormat('yuv420p');
Config.setCrf(18);
Config.setX264Preset('medium');
Config.setChromiumOpenGlRenderer('angle');
Config.setConcurrency(2);
Config.setDelayRenderTimeoutInMilliseconds(240000);
Config.setOverwriteOutput(true);
