# Private Helicopter Landing Facility - 3D YouTube Short (Remotion + Three.js)

1080x1920, 30 fps, 9:16, H.264 MP4, 65.44 s (65.04 s narration + 0.4 s tail).
No captions, no text overlays, no logos. The supplied voiceover is used byte-for-byte.

## Render on GitHub Actions
1. Push this folder to a GitHub repo (keep `public/voiceover.mp3` and `public/audio/*.wav`).
2. Actions -> "Render Helicopter Facility Short" -> Run workflow. Pick `preview` first (half-scale) to sanity-check, then `full`.
3. Download the `helicopter-facility-short` artifact (MP4 + 3 smoke-test PNGs).
The workflow runs all checks, three smoke stills, then renders with `--concurrency=2 --gl=angle` (software GL, low memory). A full render is slow on CPU runners (budget hours; timeout is set to 5.5 h).

## Render locally
`npm install && npm run check && npm run render` (or `npm start` for Remotion Studio).

## How it syncs to the narration
`npm run analyze` (already run) measures the real speech segments in `voiceover.mp3` -> `src/audioTimeline.json` (18 segments).
`src/timeline.ts` maps them to the 8 scenes and derives narration anchors (e.g. "touches down", "pour", "windsock").
Word-level anchors inside a segment (e.g. touchdown inside segment 2) are estimated by word count and may be off by a few tenths of a second.
Helicopter path, camera, weather, construction, furniture physics: `src/tracks.ts` (pure functions of time).
SFX + music: `npm run audio` (`scripts/gen-audio.ts`) generates `public/audio/music.wav` and `sfx.wav` from the same tracks (rotor sound follows real rpm and camera distance) and ducks them under the speech segments.

## Audio levels (measured on the rendered-mix inputs)
Voice -16.6 dBFS RMS; music about -32 dBFS (15 dB under); SFX about 16-20 dB under, SFX peaks <= -12 dBFS; summed peak -0.4 dBFS, no clipping.

## Files
`src/world/*` 3D scene components, `src/tracks.ts` animation data, `src/timeline.ts` audio-derived timing, `scripts/*` generators and checks, `.github/workflows/render.yml`.

## Notes / limits
- Versions pinned: remotion 4.0.250, three 0.169.0, @react-three/fiber 8.17.10, React 18.3.1. If your existing project uses other Remotion versions, change all `remotion`/`@remotion/*` versions together to the same one.
- Camera motion blur is a subtle CSS blur driven by camera speed (not multi-sample blur) to keep rendering stable.
- Conceptual visuals only: not engineering drawings and not a DIY fuel-system or helipad guide.
