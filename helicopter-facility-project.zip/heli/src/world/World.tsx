import React from 'react';
import {FPS, T} from '../timeline';
import {
  airflow,
  cameraAt,
  hangar as hangarState,
  heliState,
  OMEGA_FULL,
  pad as padState,
  rotorAngle,
  safetyZone,
  station as stationState,
  tugState,
  weather,
  windsock as windsockState,
} from '../tracks';
import {SOCK} from '../layout';
import {Atmosphere, Lights} from './Atmosphere';
import {GrassBlades, Lawn, StationGround} from './Ground';
import {Debris, Excavator, MixerTruck, ConcreteStream, PadSite} from './Pad';
import {FuelGauge, Helicopter, TugVehicle} from './Heli';
import {GardenItems, House, Trees, Windsock} from './Scenery';
import {FuelStation} from './Station';
import {Hangar} from './Hangar';
import {Airflow, Rain, SafetyZone, WindSpecks} from './Effects';
import {ramp} from '../math';

export const World = ({frame}: {frame: number}) => {
  const t = frame / FPS;
  const cam = cameraAt(t);
  const w = weather(t);
  const heli = heliState(t);
  const pad = padState(t);
  const st = stationState(t);
  const hg = hangarState(t);
  const sock = windsockState(t);
  const zone = safetyZone(t);
  const tug = tugState(t);
  const rotor = rotorAngle(frame);
  const dolly = hg.dolly;
  const wind = ramp(t, T.wind - 0.3, T.wind + 0.4) * (1 - ramp(t, 37.4, 37.9));
  const zones: [number, number, number, number, number] = [1, pad.grassScale, hg.floor > 0.02 ? 0 : 1, st.slab > 0.02 ? 0 : 1, st.patchOpacity < 0.95 ? 0 : 1];
  const gaugeK = ramp(t, T.lowFuel - 0.2, T.lowFuel + 0.2) * (1 - ramp(t, T.dive - 0.1, T.dive)) + ramp(t, 45.9, 46.2) * (1 - ramp(t, 47.1, 47.3));

  return (
    <>
      <Atmosphere w={w} cam={cam} />
      <Lights w={w} />
      <Lawn wet={w.wet} />
      <StationGround opacity={st.patchOpacity} wet={w.wet} />
      <GrassBlades t={t} heli={heli} zones={zones} wet={w.wet} />
      <PadSite t={t} p={pad} wet={w.wet} tHeliY={heli.pos[1]} />
      <Excavator x={pad.excavator.x} dig={t} on={pad.excavator.on} />
      <MixerTruck x={pad.truck.x} on={pad.truck.on} t={t} pouring={pad.chute} />
      <ConcreteStream k={pad.chute} top={pad.concreteTop} />
      <Debris t={t} />
      <House />
      <Trees t={t} heli={heli} />
      <GardenItems t={t} />
      <SafetyZone ring={zone.ring} cones={zone.cones} disc={zone.disc} />
      <Windsock pole={sock.pole} inflate={sock.inflate} t={t} x={SOCK.x} z={SOCK.z} h={SOCK.h} />
      <FuelStation s={st} t={t} wet={w.wet} />
      <FuelGauge fuel={st.fuel} visible={st.gaugeVisible || gaugeK > 0.01} t={t} k={gaugeK} />
      <Hangar h={hg} wet={w.wet} />
      <TugVehicle pos={tug.pos} yaw={tug.yaw} vis={hg.tug > 0.01 && t < 56.5} />
      <Helicopter h={heli} rotor={rotor} tailRotor={rotor * 5} wet={w.wet} dolly={dolly} t={t} />
      <Airflow t={t} k={airflow(t)} heli={heli} />
      <WindSpecks t={t} k={wind} />
      <Rain t={t} intensity={w.rain} focus={cam.look} hangarBuilt={hg.roof > 0.95} />
    </>
  );
};
void OMEGA_FULL;
