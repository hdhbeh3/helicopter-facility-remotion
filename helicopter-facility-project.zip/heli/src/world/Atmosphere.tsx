import React, {useLayoutEffect, useMemo} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {lerp, mulberry32} from '../math';
import type {Weather} from '../tracks';

const SKY_TOP = new THREE.Color('#2f86e8');
const SKY_HOR = new THREE.Color('#bfe4ff');
const STORM_TOP = new THREE.Color('#3d4857');
const STORM_HOR = new THREE.Color('#7e8996');

export const Atmosphere = ({w, cam}: {w: Weather; cam: {pos: [number, number, number]; look: [number, number, number]; fov: number}}) => {
  const {scene, gl, camera} = useThree();
  // procedural studio environment for reflections (no network assets)
  useLayoutEffect(() => {
    const pm = new THREE.PMREMGenerator(gl);
    const env = new RoomEnvironment();
    scene.environment = pm.fromScene(env, 0.04).texture;
    gl.toneMapping = THREE.ACESFilmicToneMapping;
    gl.toneMappingExposure = 1.12;
    (gl as any).localClippingEnabled = true;
    scene.fog = new THREE.Fog('#bfe4ff', 140, 560);
    return () => {
      pm.dispose();
    };
  }, []);
  const hor = SKY_HOR.clone().lerp(STORM_HOR, w.dark * 0.85);
  const top = SKY_TOP.clone().lerp(STORM_TOP, w.dark * 0.9);
  useLayoutEffect(() => {
    (scene.fog as THREE.Fog).color.copy(hor);
    scene.background = hor;
    (scene as any).environmentIntensity = lerp(1.0, 0.45, w.dark) + w.flash * 0.8;
    const c = camera as THREE.PerspectiveCamera;
    c.position.set(cam.pos[0], cam.pos[1], cam.pos[2]);
    c.lookAt(cam.look[0], cam.look[1], cam.look[2]);
    c.fov = cam.fov;
    c.near = 0.08;
    c.far = 900;
    c.updateProjectionMatrix();
  });
  const sky = useMemo(() => {
    const g = new THREE.SphereGeometry(520, 32, 20);
    const pos = g.attributes.position;
    const col = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i) / 520;
      const k = Math.pow(Math.max(0, y), 0.55);
      const c = new THREE.Color('#d9efff').lerp(new THREE.Color('#ffffff'), 0);
      // 0 at horizon -> 1 at zenith, stored as grey ramp; tinted below
      col[i * 3] = k;
      col[i * 3 + 1] = k;
      col[i * 3 + 2] = k;
      void c;
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return g;
  }, []);
  const clouds = useMemo(() => {
    const r = mulberry32(12);
    return Array.from({length: 12}, () => {
      const a = r() * 6.283;
      const d = 170 + r() * 200;
      return {x: Math.cos(a) * d, z: Math.sin(a) * d, y: 70 + r() * 60, s: 1 + r() * 1.4, p: r()};
    });
  }, []);
  // gradient sky: shader-free vertex-colour trick -> use two-colour material via onBeforeCompile
  return (
    <group>
      <mesh geometry={sky} frustumCulled={false} renderOrder={-10}>
        <shaderMaterial
          side={THREE.BackSide}
          depthWrite={false}
          fog={false}
          uniforms={{top: {value: top}, hor: {value: hor}}}
          vertexShader={'varying float vY; void main(){ vY = normalize(position).y; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }'}
          fragmentShader={'uniform vec3 top; uniform vec3 hor; varying float vY; void main(){ float k = pow(clamp(vY,0.0,1.0),0.55); gl_FragColor = vec4(mix(hor, top, k), 1.0); }'}
        />
      </mesh>
      {clouds.map((c, i) => (
        <group key={i} position={[c.x + 6 * Math.sin(c.p * 6), c.y, c.z]} scale={[c.s * 26, c.s * 7, c.s * 18]}>
          {[0, 1, 2, 3].map((k) => (
            <mesh key={k} position={[(k - 1.5) * 0.45, Math.sin(k * 1.7) * 0.12, Math.cos(k * 2.1) * 0.2]}>
              <sphereGeometry args={[0.55 - k * 0.04, 14, 10]} />
              <meshBasicMaterial color={new THREE.Color('#ffffff').lerp(new THREE.Color('#6f7886'), w.dark)} fog={false} transparent opacity={0.92} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
};

export const Lights = ({w}: {w: Weather}) => (
  <group>
    <hemisphereLight args={['#cfe8ff', '#5d7d3b', lerp(1.15, 0.5, w.dark) + w.flash * 4]} />
    <directionalLight
      position={[34, 64, 28]}
      intensity={lerp(3.4, 0.55, w.dark) + w.flash * 6}
      color={w.dark > 0.4 ? '#cfd8e6' : '#fff1d2'}
      castShadow
      shadow-mapSize-width={2048}
      shadow-mapSize-height={2048}
      shadow-camera-left={-62}
      shadow-camera-right={62}
      shadow-camera-top={62}
      shadow-camera-bottom={-62}
      shadow-camera-near={5}
      shadow-camera-far={190}
      shadow-bias={-0.0004}
      shadow-normalBias={0.04}
    />
  </group>
);
