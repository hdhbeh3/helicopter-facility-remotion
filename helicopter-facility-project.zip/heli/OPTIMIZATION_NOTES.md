# Helicopter project performance test build

Changes in this build:
- Grass instance count reduced from 7,000 to 3,500 (same seeded distribution).
- Rain streaks reduced from 1,800 to 900.
- Rotor airflow streamlines reduced from 170 to 110.
- Wind specks reduced from 140 to 90.
- Full and preview render flags aligned with the supplied Hydraulic Press project's settings: `--gl=swangle --concurrency=1`; full render also uses H.264, CRF 18, yuv420p, AAC 256k.
- GitHub Actions job timeout remains 330 minutes; it is not raised beyond the hosted-runner limit.

This is a performance-test build, not a verified speedup. Render a short benchmark and inspect its visual quality before using it for the full video.

- Workflow default is now a safe 3-second full-resolution benchmark (`quality=benchmark`); choose `full` only after reviewing benchmark speed and appearance.
